/* ************************************************* */
/* This file is a part of popular. */
/* Created by santa on 2022-03-27. */
/* Everest Engineering College. */
/* Sanepa - 2, Lalitpur. */
/* https://www.eemc.com.np */
/* ************************************************* */

#include "arithmetic.h"

#ifndef POPULAR_CONSOLE_UTILS_H
#define POPULAR_CONSOLE_UTILS_H

void displayProduct(ProductFrequency *);

#endif //POPULAR_CONSOLE_UTILS_H
